﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ToRun_OS
{
    class Finalc
    {
        public static void Interprint(string line)
        {
            string[] arg = line.Split(" ");
            string[] targ = line.Split("\"");
            if (line[0] == '\"' && !NoString(arg[0]).Contains(""))
            {
                Console.WriteLine(targ[0]);
            }
            else if (NoString(line).Contains("="))
            {
                string[] earg = line.Split("=");
                if (earg[1].Contains("\""))
                {
                    try { Str.strs.Remove(Str.get(earg[0])); } catch { }
                    Str s = new Str(earg[0]);
                }
            }
        }
        public static string NoString(string l)
        {
            try
            {
                string[] arg = null;
                arg = l.Split("\"");
                string ToReturn = "";
                arg[1] = "";
                foreach (string s in arg)
                    ToReturn += s;
                return ToReturn;
            }
            catch { }
            return "";
        }
        class Int : PrimitiveType
        {
            public int i;
            public static List<Int> ints = new List<Int>();
            public Int(string name, int value)
            {
                ints.Add(this);
                this.name = name;
                this.i = value;
            }
            public Int(string name)
            {
                ints.Add(this);
                this.name = name;
            }
            public static Int get(string Name)
            {
                foreach (Int S in ints)
                    if (S.name == Name)
                        return S;
                return null;
            }
        }
        class Str : PrimitiveType
        {
            public string i;
            public static List<Str> strs = new List<Str>();
            public Str(string name, string value)
            {
                strs.Add(this);
                this.name = name;
                this.i = value;
            }
            public Str(string name)
            {
                strs.Add(this);
                this.name = name;
            }
            public static Str get(string Name)
            {
                foreach (Str S in strs)
                    if (S.name == Name)
                        return S;
                return null;
            }
        }
        class Bool : PrimitiveType
        {

            public bool i;
            public static List<Bool> bools = new List<Bool>();
            public Bool(string name, bool value)
            {
                bools.Add(this);
                this.name = name;
                this.i = value;
            }
            public Bool(string name)
            {
                bools.Add(this);
                this.name = name;
            }
            public static Bool get(string Name)
            {
                foreach (Bool S in bools)
                    if (S.name == Name)
                        return S;
                return null;
            }

        }
    }
    class PrimitiveType
    {
        public string name;
        public int id;
    }
}
